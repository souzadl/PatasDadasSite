<div class="col-lg-6" >
    <div class="panel panel-default">
        <div class="panel-heading">
            Alimentação especial
            <a href="#" data-toggle="modal" data-target="#alimentacaoEspecialDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
        </div>    
        <div class="panel-body">
            <ul id="lista_alimentacao_especial"></ul>
        </div>
    </div>        
</div>

