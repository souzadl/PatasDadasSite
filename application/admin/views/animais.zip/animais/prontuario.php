<div class="panel panel-default">
    <div class="panel-heading">
        Saúde
    </div>    
    <div class="panel-body">
        <div class="col-lg-6" >
            <div class="panel panel-default" style="min-height: 289px;">
                <div class="panel-heading">
                    Histórico de peso
                    <a href="#" data-toggle="modal" data-target="#historicoPesoDialog"><i class="fa fa-plus-circle"></i></a>
                </div>    
                <div class="panel-body">
                    <!--
                    <table>
                        <thead>
                            <tr>
                                <th width="85%">Data de aferição</th>
                                <th>Peso</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>                            
                    -->
                </div>
            </div>        
        </div>    
        <?php $this->load->view('animais/doencaCronica.php'); ?>      
        <?php $this->load->view('animais/alimentacaoEspecial.php'); ?>  
        <?php $this->load->view('animais/deficienciaFisica.php'); ?> 
   
        <div class="col-lg-12" >
            <div class="panel panel-default">
                <div class="panel-heading">
                    Medicações
                    <a href="#" data-toggle="modal" data-target="#medicacoesDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
                </div>    
                <div class="panel-body">
                    <!--
                    <table>
                        <thead>
                            <tr>
                                <th>Medicação</th>
                                <th>Uso</th>
                                <th>Dosagem</th>
                                <th>Frequência</th>
                                <th>Contínuo</th>
                                <th>Início</th>
                                <th>Término</th>
                                <th></th>
                            <tr>
                        </thead>
                        <tbody>
                            <tr id="medicacoes_origem">
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><a href="#"><i class="fa fa-trash"></i></a></td>
                            </tr>
                        </tbody>
                    </table>-->
                </div>
            </div>        
        </div>         
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        Checklist
    </div>    
    <div class="panel-body">
        <div class="col-lg-6">
            <div class="form-group">
                <input type="checkbox" name="aptoAdocao"> Apto para adoção      
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <input type="checkbox" name="aptoEvento"> Apto para evento       
            </div>        
        </div>    
        
        <div class="col-lg-12" >
            <div class="panel panel-default">
                <div class="panel-heading">
                    Alterações de saúde    
                    <a href="#" data-toggle="modal" data-target="#alteracoesSaudeDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
                </div>    
                <div class="panel-body">
                    <!--<div class="col-lg-12">
                        <input class="form-control">
                        <label>Status</label>        
                        <select class="form-control">
                            <option value="">Selecione</option>
                        </select>            
                        <a href="#"><i class="fa fa-plus-circle fa-fw"></i></a>
                    </div>
                    
                    <div class="col-lg-6">
                        <label>Data</label> 
                        <input class="form-control datepicker" data-date-format="dd/mm/yyyy">
                    </div>
                    <div class="col-lg-6">
                        <label>Observação</label> 
                        <input class="form-control">            
                    </div>-->
                </div>
            </div>        
        </div>          
        <div class="col-lg-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Vacinas
                    <a href="#" data-toggle="modal" data-target="#vacinasDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
                </div>    
                <div class="panel-body">
                    <i class="fa fa-circle fa-fw" style="color: greenyellow;"></i>Próxima 25/05/2019
                    
                </div>
            </div>        
        </div>    
        <div class="col-lg-3" >
            <div class="panel panel-default">
                <div class="panel-heading">
                    Seresto
                    <a href="#" data-toggle="modal" data-target="#serestoDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
                </div>    
                <div class="panel-body">
                    <i class="fa fa-circle fa-fw" style="color: yellow;"></i>Próxima 25/05/2019
                    
                </div>
            </div>        
        </div>     
        <div class="col-lg-3" >
            <div class="panel panel-default">
                <div class="panel-heading">
                    Vermífugo
                    <a href="#" data-toggle="modal" data-target="#vermifugoDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
                </div>    
                <div class="panel-body">
                    <i class="fa fa-circle fa-fw" style="color: red;"></i>Próxima 25/05/2019

                </div>
            </div>        
        </div> 
        <div class="col-lg-3" >
            <div class="panel panel-default">
                <div class="panel-heading">
                    Castração
                </div>    
                <div class="panel-body">
                    <i class="fa fa-circle fa-fw" style="color: greenyellow;"></i>Castrado       
                    <select name="castracao" class="form-control">
                        <option value="">Selecione</option>
                        <option>Castrado pelo Patas</option>
                        <option>Molecão</option>
                    </select>                     
                </div>
            </div>        
        </div>           
    </div>
</div>
