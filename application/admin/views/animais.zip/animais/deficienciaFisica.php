<div class="col-lg-6" >
    <div class="panel panel-default">
        <div class="panel-heading">
            Deficiência física
            <a href="#" data-toggle="modal" data-target="#deficienciaFisicaDialog"><i class="fa fa-plus-circle fa-fw"></i></a>
        </div>    
        <div class="panel-body">
            <ul id="lista_deficiencia_fisica"></ul>
        </div>
    </div>        
</div>
